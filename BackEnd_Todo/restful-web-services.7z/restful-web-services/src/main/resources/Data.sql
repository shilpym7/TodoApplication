insert into todo(id,username,description,targetdate,is_done) values (1,'Sarwar','Learn to sleep',
sysdate(),false);
insert into todo(id,username,description,targetdate,is_done) values (2,'Sarwar','Learn to fight',
sysdate(),false);
insert into todo(id,username,description,targetdate,is_done) values (3,'Sarwar','Learn to play ludo',
sysdate(),false);
